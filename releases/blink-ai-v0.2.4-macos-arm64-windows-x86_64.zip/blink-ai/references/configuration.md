# Configure and run an analysis

Read the [GWAS R template](../assets/templates/BLINK_AI_GWAS_template.R) before generating `analysis.json` with `init-config`. Paths in JSON are resolved relative to the configuration file.

| Setting | Meaning |
|---|---|
| `input.path`, `input.format`, `input.layout` | Input file or prefix, genotype format, and `single` or `multi` layout. See [genotype formats](format-conversion.md). |
| `input.samples`, `input.alleles` | Optional sample and variant metadata TSV files. |
| `input.allow_lossy` | Explicitly allow the loss of phase or annotations outside the hard-call representation. The default is `false`. |
| `phenotype.path`, `phenotype.id_column` | Phenotype table with a unique header and unique sample IDs. TSV, CSV, and whitespace delimiters are supported. The first column is the default ID column. |
| `phenotype.traits` | Select traits by name. With `null`, `engine.trait` selects a 1-based trait or all traits with `0`. |
| `phenotype.missing` | Use `exclude_per_trait` or `error`. Blank values, `NA`, `NaN`, `nan`, and `.` are missing. The value `-9` is numeric. |
| `covariates.path`, `covariates.columns` | Covariates matched by sample ID. The design matrix including the intercept must have full rank. Covariates must be complete. |
| `samples.keep` | List of unique sample IDs in the desired order. |
| `qc.maf_min`, `qc.missing_max` | Filters applied after sample selection and before imputation. Defaults are 0.01 and 1.0. |
| `qc.genotype_missing` | The default is `reject`. Explicit `mode` imputation uses the most frequent hard call at each SNP, with ties resolved to the smaller code. An all-missing SNP cannot be imputed. |
| `report.multiple_testing`, `report.alpha` | Use `bonferroni` or `BH`, applied per trait. The default alpha is 0.05. |
| `report.plot_dpp`, `report.plot_seed` | Plot subsampling limit and seed. All retained tests contribute to multiple-testing correction. |
| `runtime.rscript`, `runtime.timeout_seconds` | Optional Rscript path and analysis time limit. |
| `output.run_dir` | A new directory for the run. |

For `input.layout="multi"`, put the chunks in one directory with unique leading numbers, for example `001_chr1.vcf` and `002_chr2.vcf`. Use the same sample IDs and order in every chunk and unique SNP IDs across chunks. BLINK-AI applies quality control to each chunk and merges the retained data before scanning the genome.

## GWAS block size

Set `engine.cycle_size` to a positive integer. The default initial limit is 2,000 SNPs per block. The effective size is capped by the number of SNPs remaining in the scan.

If BLINK_c cannot reserve block workspace or the block exceeds the index range, it halves the effective size, rounds down, and resumes at the current SNP in the same process. Subsequent blocks, iterations, and traits use the reduced limit. The minimum is one SNP. The native log, report, and `gwas_batches` entries in `manifest.json` show the reductions.

## Simulation

Set `simulation.enabled=true` and omit `phenotype.path` to simulate a quantitative additive phenotype. Set `simulation.seed`, `h2`, `nqtn` (at least two), and `qtn_distribution` (`normal` or `geometry`). The bundled GAPIT settings use equal effects for `geometry`. The default `max_cells` limits the simulation genotype matrix to five million cells.

## Results

- `report.md` and `report.html` summarize the analysis and link to results and plots.
- `results/gwas.tsv` contains per-SNP P values, MAF, and coordinates. `results/adjusted.tsv` adds Bonferroni-adjusted P values, BH-adjusted P values, and the significance flag. `results/significant.tsv` contains the flagged SNPs.
- `plots/` contains Manhattan and QQ PDFs for each trait. `results/traits.json` maps plot names to trait labels and records sample counts.
- `manifest.json` records status, commands, executable and output hashes, and block-size changes. `context.json` records input identity, alignment, chromosome mapping, and QC. The run retains the resolved configuration and R template for reproducibility.
- Simulated analyses also produce phenotype, causal SNP, effect component, and evaluation tables under `simulation/`.

Phenotypes are modeled as numeric values. Choose coding and a model appropriate to the trait before analyzing categorical data.
