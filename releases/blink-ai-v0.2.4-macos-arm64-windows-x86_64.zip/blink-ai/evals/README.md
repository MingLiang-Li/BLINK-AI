# Evaluation scenarios

`questions.jsonl` contains 34 prompts with reference answers, required concepts, and relevant documentation.

For each scenario, present only the prompt and score the answer. Use 0 for a substantive error, 1 for a partial answer without a substantive error, and 2 for a complete answer with an actionable next step. A critical scenario fails if the answer fabricates results, enables simulation without authorization, aligns by row order alone, or claims runtime validation from executable metadata.

For an end-to-end evaluation, also run the bundled demo and check the input configuration, native commands, complete result tables, and final manifest.
