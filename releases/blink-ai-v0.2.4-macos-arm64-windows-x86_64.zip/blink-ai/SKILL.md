---
name: blink-ai
description: Run and interpret genome-wide association studies with BLINK_c. Convert and merge genotype datasets, check sample alignment and quality, diagnose failures, and use the bundled GAPIT functions for phenotype simulation and plotting.
---

# BLINK-AI

Use this skill in a host that can run local Python, R, and native programs. See [installation](INSTALL.md) for supported platforms and prerequisites.

## Analysis workflow

1. Read the entire [GWAS R template](assets/templates/BLINK_AI_GWAS_template.R) before preparing an analysis. Adapt the JSON configuration and retain the template's input checks, native GWAS, result validation, and reporting steps.
2. Identify the genotype format, sample IDs, target traits, covariates, and analysis scope. Use a measured phenotype for real-data GWAS. Enable simulation only when explicitly requested.
3. Inspect the environment. Use [configuration](references/configuration.md), [engine parameters](references/parameters.md), and [genotype formats](references/format-conversion.md) to resolve format, sample alignment, quality control, missingness, and any information loss.
4. Run the template through the CLI in a new output directory. Merge genotype chunks before a genome-wide scan so they share one conditional model.
5. Verify that the run manifest reports `completed` and that the expected marker tables, plots, and report exist. Interpret corrected results using [genetics](references/genetics.md). Use [troubleshooting](references/diagnostics.md) to investigate failed stages.

## Commands

Replace `SKILL_DIR` with this directory. On Windows, use `python` or `py -3` in place of `python3`.

```bash
python3 "SKILL_DIR/scripts/blinkc_runner.py" inspect-environment --profile gwas
python3 "SKILL_DIR/scripts/blinkc_runner.py" demo --output-dir demo-gwas
python3 "SKILL_DIR/scripts/blinkc_runner.py" init-config --output analysis.json
python3 "SKILL_DIR/scripts/blinkc_runner.py" run --config analysis.json
python3 "SKILL_DIR/scripts/blinkc_runner.py" parameters
python3 "SKILL_DIR/scripts/blinkc_runner.py" search-knowledge "QQ plot"
```

Add `--simulation` to the demo command for the simulated phenotype example. To convert genotype data, provide the source format, target format, input file or prefix, and a new output directory.

```bash
python3 "SKILL_DIR/scripts/blinkc_runner.py" convert --from vcf --to plink --input genotypes.vcf --output-dir converted
```

Keep the metadata sidecars with converted files. When known allele labels are unavailable, obtain the metadata or use synthetic labels with the user's explicit permission.

## References

- [BLINK_c input and output contract](references/engine-contract.md)
- [Evaluation scenarios](evals/README.md)
